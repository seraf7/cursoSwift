import UIKit

var nombre: [Int] = [1, 2, 3, 4, 5, 6, 7, 8]

for position in Range(0 ... nombre.count - 1){
    nombre[position] *= 2
}

print(nombre)

nombre.append(10)
print(nombre)

nombre.insert(9, at: 8)
print(nombre)

nombre.insert(4, at: 8)
nombre.insert(4, at: 8)
nombre.insert(4, at: 8)

nombre.popLast()
print(nombre)

nombre.firstIndex(of: 4)

var elemento = 4
var cont = 0

for pos in Range(0 ... nombre.count - 1){
    if nombre[pos] == elemento{
        cont += 1
    }
}
