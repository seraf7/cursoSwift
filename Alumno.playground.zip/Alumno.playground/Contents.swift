import UIKit

class Alumno {
    let nombre : String
    let facultad = "Ingenieria"
    
    //Inicializador de constante
    init(nombre : String){
        self.nombre = nombre
    }
}

//Instancia de clase con argumento
let a = Alumno(nombre: "Serafin")

print(a.nombre)
