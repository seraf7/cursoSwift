import UIKit

//Declaracion de una variable, usando inferencia de datos
var str = "Hello, world"

print(str)

str = "Hola Perla :3"

print(str)

//Declaracion de una constante
let unaCadena = "Hola me llamo Serafin"

//Declaracion de una variable
var num:Int = 7

//Tipos de datos:
//Flotante      Bool
//Int           String
//Char          Arreglos
//Coleccion de datos

//Any, tipo de dato comodin
var miVar :Any = 3.14159265

miVar = "Jajaja te la creiste"

print("Hola, \(miVar)")

//Operadores
//Aritmeticos   +   -   /   *   %
//Logicos   AND(&&)     OR(||)  NOT(!)  ==  !=

//crexwel@gmail.com
