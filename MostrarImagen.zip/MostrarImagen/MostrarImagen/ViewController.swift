//
//  ViewController.swift
//  MostrarImagen
//
//  Created by 2020-1 on 9/4/19.
//  Copyright © 2019 Conde. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var vistaImagen: UIImageView!
    
    @IBAction func cambiarImagen(_ sender: Any) {
        
        var imgUno = UIImage(named: "demoOr")
        var imgDos = UIImage(named: "deemo")
        
        if(vistaImagen.image == imgDos){
            vistaImagen.image = imgUno
        }else{
            vistaImagen.image = imgDos
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

